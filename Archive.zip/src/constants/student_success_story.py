STUDENT_SUCCESS_STORY = (
    '\n\nI found value in the InCollege app, it helped me prepare for job interviews through its skills learning program.\n'
    'Through its extensive resume critique program and professional interview tips I was able to apply for multiple SDE roles this year.\n'
    'This summer I received an internship offer from one of the leading tech companies xylophone, I am happy to share my experience \n'
    '\t\t\t\t\t\t\t\t\t\t\t\t\t\t'
    '- Mark Zuckerberg')
