def display_notification(message):
  print("\n" + "\033[93m" + message + "\033[0m" + "\n")