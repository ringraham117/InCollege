import string
def format_input_first_upper(str):
  return string.capwords(str)