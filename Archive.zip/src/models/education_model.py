class Education:

    def __init__(self, edu_id="", school="", degree="", years=""):
        self.edu_id = edu_id
        self.school = school
        self.degree = degree
        self.years = years
