import src.routing.router as router
import src.constants.screen_names as screenNames

router.navigate_user(screenNames.STARTUP_SCREEN)